INSERT INTO `category` (`id`,`カテゴリー名`) VALUES (1,'洋服');
INSERT INTO `category` (`id`,`カテゴリー名`) VALUES (2,'バッグ');
INSERT INTO `category` (`id`,`カテゴリー名`) VALUES (3,'グッズ');
